package ventanas;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class Conexion {

    static String login = "ute2016";
    static String pass = "ute2016";
    static String url = "jdbc:mysql://107.180.58.67:3306/Asenut";
    static Connection link;
    
    public static void Conectar(){
    try{
            Class.forName("com.mysql.jdbc.Driver");
            link = DriverManager.getConnection(url, login, pass);
            if (link!=null) {
                //JOptionPane.showMessageDialog(null, "Bien Hecho!!");
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
    }
    
    public static void Close(){
        try {
            link.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args) {
        
        Conectar();
        Interfaz in = new Interfaz();
        in.show();
    }
}